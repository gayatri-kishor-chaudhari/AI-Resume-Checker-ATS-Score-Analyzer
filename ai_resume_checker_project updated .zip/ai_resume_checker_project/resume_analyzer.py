import re
from collections import Counter

from PyPDF2 import PdfReader


COMMON_WORDS = {
    "and", "or", "the", "a", "an", "to", "of", "in", "for", "with", "on", "by",
    "is", "are", "be", "as", "from", "this", "that", "will", "you", "your", "our",
    "we", "at", "it", "role", "candidate", "experience", "work", "team", "skills",
}

SECTION_KEYWORDS = {
    "contact": ["email", "phone", "linkedin", "github"],
    "education": ["education", "degree", "bachelor", "btech", "b.sc", "computer science"],
    "projects": ["project", "projects", "developed", "built", "implemented"],
    "skills": ["skills", "python", "sql", "git", "database"],
    "experience": ["experience", "internship", "training", "responsibilities"],
}

ACTION_VERBS = [
    "built", "developed", "created", "implemented", "designed", "deployed",
    "optimized", "integrated", "automated", "analyzed", "managed", "improved",
]


def extract_text_from_pdf(pdf_path):
    text = ""
    reader = PdfReader(str(pdf_path))
    for page in reader.pages:
        text += page.extract_text() or ""
        text += "\n"
    return text


def normalize_words(text):
    return re.findall(r"[a-zA-Z][a-zA-Z+#.]*", text.lower())


def extract_keywords(job_description, limit=25):
    words = normalize_words(job_description)
    filtered = [
        word for word in words
        if len(word) > 2 and word not in COMMON_WORDS
    ]
    counts = Counter(filtered)
    return [word for word, _ in counts.most_common(limit)]


def calculate_keyword_score(resume_words, job_keywords):
    if not job_keywords:
        return 0, [], []

    resume_word_set = set(resume_words)
    matched = [word for word in job_keywords if word in resume_word_set]
    missing = [word for word in job_keywords if word not in resume_word_set]
    score = int((len(matched) / len(job_keywords)) * 45)
    return score, matched, missing


def calculate_section_score(resume_text):
    text = resume_text.lower()
    found_sections = []

    for section, keywords in SECTION_KEYWORDS.items():
        if any(keyword in text for keyword in keywords):
            found_sections.append(section)

    score = int((len(found_sections) / len(SECTION_KEYWORDS)) * 25)
    missing_sections = [section for section in SECTION_KEYWORDS if section not in found_sections]
    return score, found_sections, missing_sections


def calculate_quality_score(resume_text):
    text = resume_text.lower()
    score = 0
    suggestions = []

    if any(verb in text for verb in ACTION_VERBS):
        score += 8
    else:
        suggestions.append("Use stronger action verbs such as developed, built, implemented, optimized, or deployed.")

    if re.search(r"\d+%|\d+\+|\d+\s*(users|projects|apis|modules|marks|cgpa)", text):
        score += 8
    else:
        suggestions.append("Add measurable impact where possible, such as project count, accuracy, users, or performance improvement.")

    if len(resume_text.split()) >= 250:
        score += 7
    else:
        suggestions.append("Add more detail to projects, technical skills, education, and internships.")

    if "github" in text or "linkedin" in text:
        score += 7
    else:
        suggestions.append("Add GitHub and LinkedIn links near the top of your resume.")

    return score, suggestions


def analyze_resume(resume_text, job_description, job_role):
    resume_words = normalize_words(resume_text)
    job_keywords = extract_keywords(job_description)

    keyword_score, matched_keywords, missing_keywords = calculate_keyword_score(
        resume_words, job_keywords
    )
    section_score, found_sections, missing_sections = calculate_section_score(resume_text)
    quality_score, quality_suggestions = calculate_quality_score(resume_text)

    ats_score = min(keyword_score + section_score + quality_score, 100)

    suggestions = []
    if missing_keywords:
        suggestions.append(
            "Add relevant missing keywords naturally: " + ", ".join(missing_keywords[:10])
        )
    if missing_sections:
        suggestions.append(
            "Improve resume structure by adding these sections: " + ", ".join(missing_sections)
        )
    suggestions.extend(quality_suggestions)

    if ats_score >= 80:
        verdict = "Strong match"
    elif ats_score >= 60:
        verdict = "Good match, but can be improved"
    elif ats_score >= 40:
        verdict = "Average match"
    else:
        verdict = "Needs improvement"

    return {
        "job_role": job_role,
        "ats_score": ats_score,
        "verdict": verdict,
        "matched_keywords": matched_keywords,
        "missing_keywords": missing_keywords,
        "found_sections": found_sections,
        "missing_sections": missing_sections,
        "suggestions": suggestions,
        "word_count": len(resume_words),
    }

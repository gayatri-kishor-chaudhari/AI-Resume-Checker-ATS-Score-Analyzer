import os
import sqlite3
from datetime import datetime
from pathlib import Path

from flask import Flask, render_template, request
from werkzeug.utils import secure_filename

from resume_analyzer import analyze_resume, extract_text_from_pdf


BASE_DIR = Path(__file__).resolve().parent
UPLOAD_FOLDER = BASE_DIR / "uploads"
DATABASE = BASE_DIR / "resume_history.db"
ALLOWED_EXTENSIONS = {"pdf"}

app = Flask(__name__)
app.config["UPLOAD_FOLDER"] = UPLOAD_FOLDER
app.config["MAX_CONTENT_LENGTH"] = 5 * 1024 * 1024


def allowed_file(filename):
    return "." in filename and filename.rsplit(".", 1)[1].lower() in ALLOWED_EXTENSIONS


def init_db():
    with sqlite3.connect(DATABASE) as conn:
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS resume_checks (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                filename TEXT NOT NULL,
                job_role TEXT NOT NULL,
                ats_score INTEGER NOT NULL,
                matched_keywords TEXT,
                missing_keywords TEXT,
                created_at TEXT NOT NULL
            )
            """
        )
        conn.commit()


def save_result(filename, job_role, result):
    with sqlite3.connect(DATABASE) as conn:
        conn.execute(
            """
            INSERT INTO resume_checks
                (filename, job_role, ats_score, matched_keywords, missing_keywords, created_at)
            VALUES (?, ?, ?, ?, ?, ?)
            """,
            (
                filename,
                job_role,
                result["ats_score"],
                ", ".join(result["matched_keywords"]),
                ", ".join(result["missing_keywords"]),
                datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            ),
        )
        conn.commit()


def get_recent_results():
    with sqlite3.connect(DATABASE) as conn:
        conn.row_factory = sqlite3.Row
        rows = conn.execute(
            """
            SELECT filename, job_role, ats_score, created_at
            FROM resume_checks
            ORDER BY id DESC
            LIMIT 5
            """
        ).fetchall()
    return rows


@app.route("/", methods=["GET", "POST"])
def index():
    init_db()
    result = None
    error = None
    recent_results = get_recent_results()

    if request.method == "POST":
        job_role = request.form.get("job_role", "Software Engineer").strip()
        job_description = request.form.get("job_description", "").strip()
        resume_file = request.files.get("resume")

        if not resume_file or resume_file.filename == "":
            error = "Please upload a PDF resume."
        elif not allowed_file(resume_file.filename):
            error = "Only PDF files are supported."
        elif not job_description:
            error = "Please paste the job description or required skills."
        else:
            filename = secure_filename(resume_file.filename)
            saved_path = app.config["UPLOAD_FOLDER"] / filename
            os.makedirs(app.config["UPLOAD_FOLDER"], exist_ok=True)
            resume_file.save(saved_path)

            resume_text = extract_text_from_pdf(saved_path)
            if not resume_text.strip():
                error = "Could not read text from this PDF. Please upload a text-based resume PDF."
            else:
                result = analyze_resume(resume_text, job_description, job_role)
                save_result(filename, job_role, result)
                recent_results = get_recent_results()

    return render_template(
        "index.html",
        result=result,
        error=error,
        recent_results=recent_results,
    )


if __name__ == "__main__":
    init_db()
    app.run(debug=True)

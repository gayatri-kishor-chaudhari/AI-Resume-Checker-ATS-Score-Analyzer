# AI Resume Checker & ATS Score Analyzer

A Python Flask web application that checks a PDF resume against a job description and generates an ATS score with matched keywords, missing keywords, resume section checks, and improvement suggestions.

## Tech Stack

- Python
- Flask
- SQLite / SQL
- PyPDF2
- HTML
- CSS

## Features

- Upload PDF resume
- Paste job description or required skills
- Extract resume text using PyPDF2
- Calculate ATS score
- Show matched and missing keywords
- Check important resume sections
- Save recent analysis history in SQLite
- Clean responsive user interface

## How To Run

1. Open this project folder in VS Code.
2. Create a virtual environment:

```bash
python -m venv venv
```

3. Activate the virtual environment:

```bash
venv\Scripts\activate
```

4. Install dependencies:

```bash
pip install -r requirements.txt
```

5. Run the Flask app:

```bash
python app.py
```

6. Open the browser:

```text
http://127.0.0.1:5000
```

## Project Structure

```text
ai_resume_checker/
├── app.py
├── resume_analyzer.py
├── requirements.txt
├── README.md
├── templates/
│   └── index.html
├── static/
│   └── css/
│       └── style.css
└── uploads/
```

## Note

This project uses rule-based keyword and resume-structure analysis. It does not send resume data to any external AI service, so it can run locally.
